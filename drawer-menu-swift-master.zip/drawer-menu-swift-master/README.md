# Drawer menu implementation in Swift 4

This is a very simple implementation of a slide menu in Swift 4. All you need is the three classes from DrawerMenu folder. Check out the Xcode project from DrawerMenuExample, if you want to see how to get started. Specifically, look into ViewController.swift class, viewDidLoad method.

<a href="https://www.iosapptemplates.com"><img src="https://www.iosapptemplates.com/wp-content/uploads/2018/01/Screen-Shot-2018-01-17-at-5.09.24-PM.png" /></a>
<a href="https://www.iosapptemplates.com"><img src="https://www.iosapptemplates.com/wp-content/uploads/2018/01/Screen-Shot-2018-01-17-at-5.09.35-PM.png" /></a>

<br/>

Supported by <a href="https://www.iosapptemplates.com">iOS App Templates</a>.